TOP FITNESS — PROYECTO ANDROID PARA JSTUDIO

Este paquete convierte la aplicación web TOP Fitness en una APK Android mediante WebView.
No requiere Capacitor ni Node.js para compilar el proyecto Android.

ABRIR EN JSTUDIO
1. Descomprime este ZIP en una carpeta accesible desde JStudio.
2. En JStudio usa el menú/gestor de proyectos para abrir IMPORTAR/ABRIR PROYECTO y selecciona la carpeta que contiene settings.gradle.
3. Espera a que JStudio sincronice Gradle.
4. Ejecuta la tarea de Gradle assembleDebug (si aparece en la interfaz de Gradle).
5. La APK de prueba quedará en: app/build/outputs/apk/debug/app-debug.apk

NOTAS
- Package: com.topfitness.app
- Nombre: TOP Fitness
- Min SDK: 23
- Target SDK: 34
- La app funciona con los datos locales del HTML/IndexedDB y no necesita Internet para la lógica principal.
- El selector de fotos permite galería y cámara; Android solicitará permiso de cámara cuando sea necesario.
- No edites MainActivity.java salvo que te lo indique.

SI JSTUDIO PIDE INSTALAR/SINCRONIZAR COMPONENTES
No instales nada al azar. Envíame una captura de esa pantalla y te digo exactamente qué componente seleccionar.
